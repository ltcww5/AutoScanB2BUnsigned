﻿//-----------------------------------------------------------------------
// <copyright file="WebSpiderStatus.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : zifang
// * FileName: WebSpiderStatus.cs
// * history : created by zifang 2015-07-02 14:34:27 
// </copyright>
//-----------------------------------------------------------------------
using Better517Na.ChinaPNRATOQSSignPlugin.Model;

namespace Better517Na.ChinaPNRATOQSSignPlugin.Business
{
    /// <summary>
    /// 爬取状态
    /// </summary>
    public class WebSpiderStatus
    {
        /// <summary>
        /// 初始化
        /// </summary>
        public WebSpiderStatus()
        {
            this.NextOperating = MOperator.Manage;
        }

        /// <summary>
        /// 下一个操作
        /// </summary>
        public MOperator NextOperating
        {
            get;
            set;
        }

        /// <summary>
        /// 改签列表当前页
        /// </summary>
        public int RefundListCurrentPage
        {
            get;
            set;
        }

        /// <summary>
        /// 改签列表总页
        /// </summary>
        public int RefundListTotalPage
        {
            get;
            set;
        }
    }
}
