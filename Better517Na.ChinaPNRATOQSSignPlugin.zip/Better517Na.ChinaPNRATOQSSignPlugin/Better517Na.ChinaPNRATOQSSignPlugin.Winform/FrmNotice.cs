﻿//-----------------------------------------------------------------------
// <copyright file="FrmNotice.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : zifang
// * FileName: FrmNotice.cs
// * history : created by jiutian 2016-07-29 09:27:27 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Better517Na.ChinaPNRATOQSSignPlugin.Winform
{
    /// <summary>
    /// 提示窗口实例
    /// </summary>
    public partial class FrmNotice : Form
    {
        /// <summary>
        /// 忽略大小
        /// </summary>
        private const uint SWPNOSIZE = 0x0001;

        /// <summary>
        /// 忽略位置
        /// </summary>
        private const uint SWPNOMOVE = 0x0002;

        /// <summary>
        /// 窗口顶层
        /// </summary>
        private static readonly IntPtr HWNDTOPMOST = new IntPtr(-1);

        /// <summary>
        /// 单例窗口
        /// </summary>
        private static FrmNotice form = null;

        /// <summary>
        /// 上一次展示时间
        /// </summary>
        ////private static DateTime lastShowTime = DateTime.MinValue;

        /// <summary>
        /// 私有构造函数
        /// </summary>
        private FrmNotice()
        {
            this.InitializeComponent();
            SetWindowPos(this.Handle, HWNDTOPMOST, 0, 0, 0, 0, SWPNOMOVE | SWPNOSIZE);
        }

        /// <summary>
        /// 公开获取对象方法
        /// </summary>
        /// <param name="msg">提示消息</param>
        /// <returns>窗口对象</returns>
        public static FrmNotice GetSingleForm(string msg)
        {
            if (form == null)
            {
                form = new FrmNotice();
            }

            form.label1.Text = msg;

            return form;
        }

        /// <summary>
        /// 窗口展示 多少分钟内只展示一次
        /// </summary>
        public new void Show()
        {
            ////if (DateTime.Now.Subtract(lastShowTime).TotalMinutes > 5)
            ////{
            ////    lastShowTime = DateTime.Now;
            try
            {
                base.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            ////}
        }

        /// <summary>
        /// 窗口置顶
        /// </summary>
        /// <param name="hwnd">窗口句柄</param>
        /// <param name="hwndInsertAfter">显示模式</param>
        /// <param name="x">以客户坐标指定窗口新位置的左边界</param>
        /// <param name="y">以客户坐标指定窗口新位置的顶边界</param>
        /// <param name="cx">以像素指定窗口的新的宽度</param>
        /// <param name="cy">以像素指定窗口的新的高度</param>
        /// <param name="uflags">窗口尺寸和定位的标志</param>
        /// <returns>如果函数成功，返回值为非零；如果函数失败，返回值为零</returns>
        [DllImport("user32.dll", EntryPoint = "SetWindowPos")]
        private static extern bool SetWindowPos(IntPtr hwnd, IntPtr hwndInsertAfter, int x, int y, int cx, int cy, uint uflags);

        /// <summary>
        /// 关闭时间
        /// </summary>
        /// <param name="sender">放松这</param>
        /// <param name="e">参数</param>
        private void FrmNotice_FormClosed(object sender, FormClosedEventArgs e)
        {
            form = null;
        }
    }
}
