﻿//-----------------------------------------------------------------------
// <copyright file="MainProcess.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : jiutian
// * FileName: MainProcess.cs
// * history : created by jiutian 2016-07-29 09:26:27 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Better.Infrastructures.Log;
using Better517Na.ChinaPNRATOQSSignPlugin.Model;
using System.Drawing;
using mshtml;

namespace Better517Na.ChinaPNRATOQSSignPlugin.Winform
{
    /// <summary>
    /// 主窗体类
    /// </summary>
    public partial class MainProcess : Form
    {
        /// <summary>
        /// 爬虫状态
        /// </summary>
        ////private WebSpiderStatus spiderStatus = null;

        private MOperator nextOperating = MOperator.Manage;
        /// <summary>
        /// 操作集合
        /// </summary>
        private Dictionary<MOperator, Operate> opera = null;

        private bool isFirst = true;
        ///// <summary>
        ///// 爬取数据
        ///// </summary>
        //private DataResource dataResource = null;

        /// <summary>
        /// 是否在刷新
        /// </summary>
        private bool isrefreshing = false;

        /// <summary>
        /// 窗体初始化
        /// </summary>
        public MainProcess()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// 操作委托
        /// </summary>
        private delegate void Operate();

        /// <summary>
        /// 事件
        /// </summary>
        private event Operate WebbrowerExcuteEvent;

        /// <summary>
        /// 任务栏黄色闪烁
        /// </summary>
        /// <param name="handle">handle</param>
        /// <param name="invert">不知道什么意义</param>
        /// <returns>结果</returns>
        [DllImport("user32.dll")]
        private static extern bool FlashWindow(IntPtr handle, bool invert);

        /// <summary>
        /// 定义方法
        /// </summary>
        private void DefineSpideMethod()
        {
            this.opera = new Dictionary<MOperator, Operate>()
                {
                    { MOperator.Manage, new Operate(this.Manage) },
                    { MOperator.AddAirOperator, new Operate(this.AddAirOperator) },
                    { MOperator.ConfirmAdd, new Operate(this.ConfirmAdd) },
                    { MOperator.Submit, new Operate(this.Submit) },
                };
        }

        /////// <summary>
        /////// 浏览器打开新窗口之前事件
        /////// </summary>
        /////// <param name="sender">发送者</param>
        /////// <param name="e">参数</param>
        ////private void WebBrowser1_NewWindow(object sender, CancelEventArgs e)
        ////{
        ////    e.Cancel = true;
        ////}

        /// <summary>
        /// 页面加载完成事件
        /// </summary>
        /// <param name="sender">发送者</param>
        /// <param name="e">参数</param>
        private void Web_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (this.webBrower.ReadyState != WebBrowserReadyState.Complete)
            {
                return;
            }
            else
            {
                if (this.webBrower.DocumentTitle == "汇付天下-PNR钱管家")
                {
                    //if (this.isFirst)
                    //{
                    //    this.isFirst = false;
                    //    this.DelegateExcute(this.opera[this.nextOperating]);
                    //}
                    //else
                    //{
                    //if (this.webBrower.Document.GetElementById("tbl_base2") != null || this.webBrower.Document.GetElementById("authCard") != null)
                    //{
                    this.DelegateExcute(this.opera[this.nextOperating]);
                    //}
                    //}
                }

                if (this.webBrower.DocumentTitle == "欢迎使用汇付天下PNR钱管家")
                {
                    MainProcess.ShowNoticeForm("淘宝帐号已掉线，请登录！");
                }
            }
        }

        /// <summary>
        /// 提示窗口显示
        /// </summary>
        /// <param name="msg">提示消息</param>
        public static void ShowNoticeForm(string msg)
        {
            FlashWindow(new MainProcess().Handle, true);

            FrmNotice notice = FrmNotice.GetSingleForm(msg);
            notice.TopMost = true;
            notice.Show();
            notice.TopMost = true;
            int iactulaWidth = Screen.PrimaryScreen.Bounds.Width;
            int workHeight = SystemInformation.WorkingArea.Height;
            notice.Location = new System.Drawing.Point(iactulaWidth - notice.Width, workHeight - notice.Height);
        }

        private void MainProcess_Load(object sender, EventArgs e)
        {
            this.statusStrip1.Text = "加载";
            string hostName = Dns.GetHostName();
            TrackIdManager.GetInstance(hostName);
            ////this.spiderStatus = new WebSpiderStatus();
            this.DefineSpideMethod();
            this.webBrower.ScriptErrorsSuppressed = true;
            this.webBrower.Navigate("https://mas.chinapnr.com/gau/login.jsp");

            this.webBrower.DocumentCompleted += this.Web_DocumentCompleted;
            ////this.webBrower.NewWindow += this.WebBrowser1_NewWindow;
            //OrderGetAndUpdateBusi getOrder = new OrderGetAndUpdateBusi();
            //Action actionGet = new Action(getOrder.GetRefundOrder);
            //Task getTask = new Task(actionGet);
            //getTask.Start();

            //OrderGetAndUpdateBusi orderUpdate = new OrderGetAndUpdateBusi();
            //Action actionUpdate = new Action(orderUpdate.UpdateRefundOrder);
            //Task updateTask = new Task(actionUpdate);
            //updateTask.Start();
            //LogBusi log = new LogBusi();
            //Action<object> actionlog = new Action<object>(log.WriteOnlineLog);
            //Task logtask = new Task(actionlog, hostName);
            //logtask.Start();
            //this.LogLoginOut(0);
        }

        /// <summary>
        /// 执行委托
        /// </summary>
        /// <param name="operater">未果</param>
        private void DelegateExcute(Operate operater)
        {
            try
            {
                Application.DoEvents();
                operater();
            }
            catch (Exception ex)
            {
                AppException appex = new AppException(ex.Message, ex, ExceptionLevel.Error);
                LogManager.Log.WriteException(appex);
                MainProcess.ShowNoticeForm("程序异常,请重启");
            }
        }

        private void Manage()
        {
            this.ChangeStatuText("功能管理");
            this.webBrower.Document.GetElementById("managehref").InvokeMember("click");
            this.nextOperating = MOperator.AddAirOperator;
        }

        private void OperatorManager()
        { 
        ////this.webBrower
        }


        private void AddAirOperator()
        {
            string gethtml = string.Empty;
            using (System.IO.StreamReader getReader = new System.IO.StreamReader(this.webBrower.DocumentStream, System.Text.Encoding.GetEncoding("gb2312")))
            {
                gethtml = getReader.ReadToEnd();
            }
            HtmlElementCollection addAirOprator = this.webBrower.Document.GetElementsByTagName("body")[0].GetElementsByTagName("table")[2].All;
            ////HtmlElementCollection addAirOpratorHref = addAirOprator.GetElementsByName("a");
            foreach (HtmlElement item in addAirOprator)
            {
                if (item.InnerText.Equals("新增航空公司操作员"))
                {
                    item.InvokeMember("click");
                    break;
                }
            }

            this.nextOperating = MOperator.ConfirmAdd;
        }

        private void ConfirmAdd()
        {
            string gethtml = string.Empty;
            using (System.IO.StreamReader getReader = new System.IO.StreamReader(this.webBrower.DocumentStream, System.Text.Encoding.GetEncoding("gb2312")))
            {
                gethtml = getReader.ReadToEnd();
            }

            HtmlElement airCompany = this.webBrower.Document.GetElementById("mers_info");
            HtmlElementCollection subAirCompany = airCompany.Children;
            foreach (HtmlElement item in subAirCompany)
            {
                if (item.InnerText.Equals("深航B2B"))
                {
                    string temp = item.GetAttribute("value");
                    airCompany.SetAttribute("value", temp);
                    break;
                }
            }

            HtmlElement operId = this.webBrower.Document.GetElementById("operId");
            operId.SetAttribute("value", "sss");

            HtmlElement operName = this.webBrower.Document.GetElementById("operName");
            operName.SetAttribute("value", "sss");
            HtmlElement transPwd = this.webBrower.Document.GetElementById("transPwd");
            transPwd.SetAttribute("value", "sss");
            HtmlElement transPwdConf = this.webBrower.Document.GetElementById("transPwdConf");
            transPwdConf.SetAttribute("value", "sss");
            HtmlElement operMail = this.webBrower.Document.GetElementById("operMail");
            operMail.SetAttribute("value", "sss");
            HtmlElement operTel = this.webBrower.Document.GetElementById("operTel");
            operTel.SetAttribute("value", "sss");

            HtmlElement confirmAdd = this.webBrower.Document.GetElementById("btn1");
            confirmAdd.InvokeMember("click");
            //// 是否已存在存在
            this.nextOperating = MOperator.Submit;


        }

        private void Submit()
        {
            Bitmap bitmap = null;
            Image authCard = null;

            try
            {
                authCard = this.GetWebImage(this.webBrower, this.webBrower.Document.GetElementById("authCard"));
                bitmap = new Bitmap(authCard);
                bitmap.Save(string.Format("E:/veryzhunma/处理后图片Flight/{0}", "我的图片处理.png"), System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            finally
            {
                if (bitmap != null)
                {
                    bitmap.Dispose();
                }

                if (authCard != null)
                {
                    authCard.Dispose();
                }
            }
        }

        /// <summary>  
        /// 返回指定WebBrowser中图片<IMG></IMG>中的图内容  
        /// </summary>  
        /// <param name="WebCtl">WebBrowser控件</param>  
        /// <param name="ImgeTag">IMG元素</param>  
        /// <returns>IMG对象</returns>  
        private Image GetWebImage(WebBrowser WebCtl, HtmlElement ImgeTag)
        {
            HTMLDocument doc = (HTMLDocument)WebCtl.Document.DomDocument;
            HTMLBody body = (HTMLBody)doc.body;
            IHTMLControlRange rang = (IHTMLControlRange)body.createControlRange();
            IHTMLControlElement Img = (IHTMLControlElement)ImgeTag.DomElement; //图片地址  
            Image oldImage = Clipboard.GetImage();
            rang.add(Img);
            rang.execCommand("Copy", false, null);  //拷贝到内存  
            Image numImage = Clipboard.GetImage();
            try
            {
                Clipboard.SetImage(oldImage);
            }
            catch { }
            return numImage;
        }

        /////// <summary>
        /////// 定时刷新
        /////// </summary>
        /////// <param name="sender">发送者</param>
        /////// <param name="e">参数</param>
        ////private void Refresh_Tick(object sender, EventArgs e)
        ////{
        ////    try
        ////    {
        ////        if (this.isrefreshing)
        ////        {
        ////            this.spiderStatus = new WebSpiderStatus();
        ////            this.spiderStatus.NextOperating = MOperator.None;

        ////            if (this.WebbrowerExcuteEvent == null)
        ////            {
        ////                this.WebbrowerExcuteEvent += new Operate(this.RefreshOper);
        ////            }

        ////            this.WebbrowerExcuteEvent.BeginInvoke(null, null);

        ////            this.isrefreshing = false;
        ////        }
        ////    }
        ////    catch (Exception ex)
        ////    {
        ////        AppException appex = new AppException(ex.Message, ex, ExceptionLevel.Error);
        ////        LogManager.Log.WriteException(appex);
        ////    }
        ////}

        /////// <summary>
        /////// 定时爬
        /////// </summary>
        /////// <param name="sender">发送者</param>
        /////// <param name="e">参数</param>
        ////private void Spide_Tick(object sender, EventArgs e)
        ////{
        ////    try
        ////    {
        ////        // 没有执行，并且没有刷新
        ////        if (!this.isrefreshing)
        ////        {
        ////            Checker check = new Checker();
        ////            check.GetEnvirementArg();
        ////            string hostName = Dns.GetHostName();
        ////            TrackIdManager.GetInstance(hostName);
        ////            this.spiderStatus = new WebSpiderStatus();
        ////            this.spiderStatus.NextOperating = MOperator.ToRefundManage;
        ////            if (this.WebbrowerExcuteEvent == null)
        ////            {
        ////                this.WebbrowerExcuteEvent += new Operate(this.RefreshOper);
        ////            }

        ////            this.WebbrowerExcuteEvent.BeginInvoke(null, null);
        ////        }
        ////    }
        ////    catch (Exception ex)
        ////    {
        ////        AppException appex = new AppException(ex.Message, ex, ExceptionLevel.Error);
        ////        LogManager.Log.WriteException(appex);
        ////    }
        ////}

        /// <summary>
        /// 更新状态
        /// </summary>
        /// <param name="txt">状态</param>
        private void ChangeStatuText(string txt)
        {
            this.Invoke(new Action(() =>
            {
                this.status.Text = txt;
            }));
        }

        /////// <summary>
        /////// 关闭前
        /////// </summary>
        /////// <param name="sender">发送者</param>
        /////// <param name="e">参数</param>
        ////private void FrmAliTripOrderGetter_FormClosing(object sender, FormClosingEventArgs e)
        ////{
        ////    this.webBrower.Document.Cookie = this.webBrower.Document.Cookie.Remove(0, this.webBrower.Document.Cookie.Length - 1);
        ////    this.LogLoginOut(1);
        ////}

        /////// <summary>
        /////// 记录登录日志
        /////// </summary>
        /////// <param name="login">0 登录 1 退出</param>
        ////private void LogLoginOut(int login)
        ////{
        ////    string hostName = Dns.GetHostName();
        ////    string content = hostName + "|" + (login == 1 ? "登录" : "退出");
        ////    LogBusi logBusi = new LogBusi();
        ////    Action<object> action = new Action<object>(logBusi.WriteLog);
        ////    action.BeginInvoke(content, null, null);
        ////}
    }
}
