﻿//-----------------------------------------------------------------------
// <copyright file="MainProcess.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : zifang
// * FileName: MainProcess.cs
// * history : created by jiutian 2016-07-29 09:26:27 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Better517Na.ChinaPNRATOQSSignPlugin.Winform
{
    public partial class InitForm : Form
    {

        public static Dictionary<string, string> passWordCard = new Dictionary<string, string>();
        public InitForm()
        {
            InitializeComponent();
        }

        private void btCrateTable_Click(object sender, EventArgs e)
        {
            if (this.tbLine != null && !this.tbLine.Text.Equals("0") && !this.tbLine.Text.Equals(string.Empty))
            {
                this.dataGridViewPass.ColumnCount = int.Parse(this.tbLine.Text);
            }
            else
            {
                MainProcess.ShowNoticeForm("请输入正确的行数");
            }

            if (this.tbColumn != null && !this.tbColumn.Text.Equals("0") && !this.tbColumn.Text.Equals(string.Empty))
            {
                this.dataGridViewPass.RowCount = int.Parse(this.tbColumn.Text);
            }
            else
            {
                MainProcess.ShowNoticeForm("请输入正确的列数");
            }
        }

        private void btRecord_Click(object sender, EventArgs e)
        {
            int rows = 0;
            int column = 0;
            rows = this.dataGridViewPass.Rows.Count;
            column = this.dataGridViewPass.ColumnCount;
            try
            {
                if (rows > 0)
                {
                    for (int i = 1; i < rows; i++)
                    {
                        for (int j = 1; j < column; j++)
                        {
                            string key = string.Empty;
                            string value = string.Empty;
                            key = this.dataGridViewPass.Rows[i].Cells[0].Value.ToString() + this.dataGridViewPass.Rows[0].Cells[j].Value.ToString();
                            value = this.dataGridViewPass.Rows[i].Cells[j].Value.ToString();
                            passWordCard[key] = value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MainProcess.ShowNoticeForm(ex.Message);
            }

            this.dataGridViewPass.Rows.Clear();
        }

        /// <summary>
        /// 打开业务处理窗体
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        private void btnRun_Click(object sender, EventArgs e)
        {
            new MainProcess().Show();
            this.Hide();
        }
    }
}
