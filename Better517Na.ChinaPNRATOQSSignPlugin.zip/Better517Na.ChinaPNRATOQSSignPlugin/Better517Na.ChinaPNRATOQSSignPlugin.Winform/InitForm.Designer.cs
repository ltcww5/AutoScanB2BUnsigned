﻿namespace Better517Na.ChinaPNRATOQSSignPlugin.Winform
{
    partial class InitForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pPasswordCard = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lineNu = new System.Windows.Forms.Label();
            this.columnNu = new System.Windows.Forms.Label();
            this.tbLine = new System.Windows.Forms.TextBox();
            this.tbColumn = new System.Windows.Forms.TextBox();
            this.btCrateTable = new System.Windows.Forms.Button();
            this.btRecord = new System.Windows.Forms.Button();
            this.btnRun = new System.Windows.Forms.Button();
            this.dataGridViewPass = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.pPasswordCard.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPass)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.btRecord);
            this.panel1.Controls.Add(this.btCrateTable);
            this.panel1.Controls.Add(this.tbColumn);
            this.panel1.Controls.Add(this.tbLine);
            this.panel1.Controls.Add(this.columnNu);
            this.panel1.Controls.Add(this.lineNu);
            this.panel1.Controls.Add(this.pPasswordCard);
            this.panel1.Location = new System.Drawing.Point(1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 311);
            this.panel1.TabIndex = 0;
            // 
            // pPasswordCard
            // 
            this.pPasswordCard.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pPasswordCard.Controls.Add(this.dataGridViewPass);
            this.pPasswordCard.Location = new System.Drawing.Point(122, 13);
            this.pPasswordCard.Name = "pPasswordCard";
            this.pPasswordCard.Size = new System.Drawing.Size(373, 274);
            this.pPasswordCard.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.btnRun);
            this.panel2.Location = new System.Drawing.Point(0, 316);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(600, 101);
            this.panel2.TabIndex = 1;
            // 
            // lineNu
            // 
            this.lineNu.AllowDrop = true;
            this.lineNu.AutoSize = true;
            this.lineNu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lineNu.Location = new System.Drawing.Point(16, 41);
            this.lineNu.Name = "lineNu";
            this.lineNu.Size = new System.Drawing.Size(31, 14);
            this.lineNu.TabIndex = 2;
            this.lineNu.Text = "行数";
            // 
            // columnNu
            // 
            this.columnNu.AutoSize = true;
            this.columnNu.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.columnNu.Location = new System.Drawing.Point(16, 100);
            this.columnNu.Name = "columnNu";
            this.columnNu.Size = new System.Drawing.Size(29, 12);
            this.columnNu.TabIndex = 3;
            this.columnNu.Text = "列数";
            // 
            // tbLine
            // 
            this.tbLine.Location = new System.Drawing.Point(16, 57);
            this.tbLine.Name = "tbLine";
            this.tbLine.Size = new System.Drawing.Size(100, 21);
            this.tbLine.TabIndex = 4;
            // 
            // tbColumn
            // 
            this.tbColumn.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.tbColumn.Location = new System.Drawing.Point(16, 115);
            this.tbColumn.Name = "tbColumn";
            this.tbColumn.Size = new System.Drawing.Size(100, 21);
            this.tbColumn.TabIndex = 5;
            // 
            // btCrateTable
            // 
            this.btCrateTable.Location = new System.Drawing.Point(16, 158);
            this.btCrateTable.Name = "btCrateTable";
            this.btCrateTable.Size = new System.Drawing.Size(75, 23);
            this.btCrateTable.TabIndex = 6;
            this.btCrateTable.Text = "生成口令卡";
            this.btCrateTable.UseVisualStyleBackColor = true;
            this.btCrateTable.Click += new System.EventHandler(this.btCrateTable_Click);
            // 
            // btRecord
            // 
            this.btRecord.Location = new System.Drawing.Point(16, 218);
            this.btRecord.Name = "btRecord";
            this.btRecord.Size = new System.Drawing.Size(75, 23);
            this.btRecord.TabIndex = 7;
            this.btRecord.Text = "录入后确认";
            this.btRecord.UseVisualStyleBackColor = true;
            this.btRecord.Click += new System.EventHandler(this.btRecord_Click);
            // 
            // btnRun
            // 
            this.btnRun.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRun.Location = new System.Drawing.Point(214, 20);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(145, 36);
            this.btnRun.TabIndex = 0;
            this.btnRun.Text = "运行";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // dataGridViewPass
            // 
            this.dataGridViewPass.AllowUserToAddRows = false;
            this.dataGridViewPass.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPass.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewPass.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewPass.Name = "dataGridViewPass";
            this.dataGridViewPass.RowTemplate.Height = 23;
            this.dataGridViewPass.Size = new System.Drawing.Size(373, 274);
            this.dataGridViewPass.TabIndex = 0;
            // 
            // InitForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 413);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "InitForm";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pPasswordCard.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPass)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pPasswordCard;
        private System.Windows.Forms.Label columnNu;
        private System.Windows.Forms.Label lineNu;
        private System.Windows.Forms.Button btCrateTable;
        private System.Windows.Forms.TextBox tbColumn;
        private System.Windows.Forms.TextBox tbLine;
        private System.Windows.Forms.Button btRecord;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.DataGridView dataGridViewPass;
    }
}

