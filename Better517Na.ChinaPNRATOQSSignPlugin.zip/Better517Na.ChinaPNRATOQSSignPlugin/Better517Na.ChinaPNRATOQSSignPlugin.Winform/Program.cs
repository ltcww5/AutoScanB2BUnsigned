﻿//-----------------------------------------------------------------------
// <copyright file="MainProcess.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : jiutian
// * FileName: MainProcess.cs
// * history : created by jiutian 2016-07-29 09:26:27 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Better517Na.ChinaPNRATOQSSignPlugin.Winform
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new InitForm());
            ////Application.Run(new MainProcess());
            
        }
    }
}
