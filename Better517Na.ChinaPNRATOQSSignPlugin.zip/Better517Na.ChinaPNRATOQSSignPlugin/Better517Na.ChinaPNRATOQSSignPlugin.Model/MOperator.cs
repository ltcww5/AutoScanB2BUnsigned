﻿//-----------------------------------------------------------------------
// <copyright file="MainProcess.cs" company="517Na Enterprises">
// * Copyright (C) 2015 517Na科技有限公司 版权所有。
// * version : 2.0.50727.5485
// * author  : jiutian
// * FileName: MainProcess.cs
// * history : created by jiutian 2016-07-29 09:26:27 
// </copyright>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Better517Na.ChinaPNRATOQSSignPlugin.Model
{
    /// <summary>
    /// 操作枚举
    /// </summary>
    public enum MOperator
    {
        /// <summary>
        /// 不执行任何操作
        /// </summary>
        None = 0,

        /// <summary>
        /// 功能管理
        /// </summary>
        Manage = 1,

        /// <summary>
        /// 操作员管理
        /// </summary>
        OperatorManager=2,

        /// <summary>
        /// 新增航司操作员
        /// </summary>
        AddAirOperator = 3,

        /// <summary>
        /// 确认增加
        /// </summary>
        ConfirmAdd = 4,

        /// <summary>
        /// 新增航司操作员提交
        /// </summary>
        Submit = 5,
    }
}
